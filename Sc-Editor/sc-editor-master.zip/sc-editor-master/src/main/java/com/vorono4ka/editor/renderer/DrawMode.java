package com.vorono4ka.editor.renderer;

public enum DrawMode {
    TRIANGLES,
    TRIANGLE_STRIP,
    TRIANGLE_FAN,
    LINES,
    POINTS
}
