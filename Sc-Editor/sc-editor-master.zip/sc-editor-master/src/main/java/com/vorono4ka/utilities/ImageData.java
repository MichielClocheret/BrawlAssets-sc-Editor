package com.vorono4ka.utilities;

public record ImageData(int width, int height, int[] pixels) {
}
