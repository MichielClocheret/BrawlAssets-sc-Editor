package com.vorono4ka.editor.renderer.gl;

import com.vorono4ka.editor.renderer.gl.buffers.BufferObject;

public class Vao implements BufferObject {
    private final GLRendererContext gl;
    private final int id;

    public Vao(GLRendererContext gl) {
        this.gl = gl;

        this.id = gl.glGenVertexArray();
    }

    @Override
    public void bind() {
        gl.glBindVertexArray(this.id);
    }

    @Override
    public void unbind() {
        gl.glBindVertexArray(0);
    }

    @Override
    public void delete() {
        gl.glDeleteVertexArray(this.id);
    }
}
