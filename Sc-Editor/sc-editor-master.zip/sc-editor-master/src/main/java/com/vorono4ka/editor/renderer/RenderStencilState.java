package com.vorono4ka.editor.renderer;

public enum RenderStencilState {
    NONE, SCISSORS, ENABLED, RENDERING_MASKED, DISABLED, RENDERING_UNMASKED
}
